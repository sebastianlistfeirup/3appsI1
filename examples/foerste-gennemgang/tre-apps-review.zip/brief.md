# Tre apps · første gennemgang

Gennemgå to konkrete eksempelresultater og vælg et afgrænset næste forsøg.

## Acceptkrav
- Begge leverancer har et selvstændigt review
- Begrænsningerne indgår i beslutningen
- Næste forsøg er konkret og afgrænset

## Begrænsninger
Syntetiske data. Ingen kundeoplysninger, betalte kald, cloudforbindelse eller automatisk forretningsgodkendelse. Studio-forløbene er manuelle.
